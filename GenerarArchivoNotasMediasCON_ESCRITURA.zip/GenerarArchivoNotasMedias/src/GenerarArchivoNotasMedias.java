
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 *
 * @author Kiril_SP
 */
public class GenerarArchivoNotasMedias {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        alumnoNotaMedia();
    }

    @SuppressWarnings({"UnusedAssignment", "CallToPrintStackTrace"})
    public static void alumnoNotaMedia() {

        @SuppressWarnings("UnusedAssignment")
        File archivo = null;
        File archivoMedia = null;

        FileReader fr = null;
        FileWriter fw = null;

        @SuppressWarnings("UnusedAssignment")
        BufferedReader br = null;

        BufferedWriter bw = null;

        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
            archivo = new File("./src/ArchivosAlumnos.txt");

            archivoMedia = new File("./src/ArchivosAlumnosMedia.txt");
            fr = new FileReader(archivo);
            br = new BufferedReader(fr);

            fw = new FileWriter(archivoMedia, true);
            bw = new BufferedWriter(fw);

            // Lectura del fichero
            String linea;

            int nota1, nota2, nota3;

            double media;

            while ((linea = br.readLine()) != null) {

                String soloNumeros = linea.replaceAll("[^0-9]", " ");

                String[] notasArray = soloNumeros.split("\\s+");

                nota1 = Integer.parseInt((String) Array.get(notasArray, 1));
                nota2 = Integer.parseInt((String) Array.get(notasArray, 2));
                nota3 = Integer.parseInt((String) Array.get(notasArray, 3));

                media = (nota1 + nota2 + nota3) / 3;

                String nombre = linea.substring(0, linea.indexOf(":"));

                System.out.println(nombre + ":" + media);

                String escritura = nombre + ":" + media;

                bw.write(escritura);
                bw.newLine();
                bw.flush();

            }

        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        } finally {
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta 
            // una excepcion.
            try {
                if (null != fr) {
                    fr.close();
                }
            } catch (IOException e2) {
                e2.printStackTrace();
            }

            try {
                if (null != fw) {
                    fw.close();
                }
            } catch (IOException e2) {
                e2.printStackTrace();
            }
        }
    }
}
